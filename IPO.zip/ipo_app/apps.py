from django.apps import AppConfig


class IpoAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ipo_app'
