from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import date, timedelta
from ipo_app.models import IPO


class Command(BaseCommand):
    help = 'Populate the database with sample IPO data'

    def handle(self, *args, **options):
        self.stdout.write('Creating sample IPO data...')

        # Sample IPO data
        sample_ipos = [
            {
                'company_name': 'TechCorp Solutions Ltd',
                'price_band': '₹1000-1100',
                'open_date': date.today() + timedelta(days=10),
                'close_date': date.today() + timedelta(days=13),
                'issue_size': 500.00,
                'issue_type': 'book_building',
                'status': 'upcoming',
            },
            {
                'company_name': 'GreenEnergy Power Ltd',
                'price_band': '₹800-900',
                'open_date': date.today() + timedelta(days=5),
                'close_date': date.today() + timedelta(days=8),
                'issue_size': 300.00,
                'issue_type': 'book_building',
                'status': 'upcoming',
            },
            {
                'company_name': 'DigitalPay Systems Ltd',
                'price_band': '₹1200-1300',
                'open_date': date.today() - timedelta(days=2),
                'close_date': date.today() + timedelta(days=1),
                'issue_size': 750.00,
                'issue_type': 'book_building',
                'status': 'ongoing',
            },
            {
                'company_name': 'HealthTech Innovations Ltd',
                'price_band': '₹900-1000',
                'open_date': date.today() - timedelta(days=5),
                'close_date': date.today() - timedelta(days=2),
                'issue_size': 400.00,
                'issue_type': 'book_building',
                'status': 'ongoing',
            },
            {
                'company_name': 'FinTech Solutions Ltd',
                'price_band': '₹1500-1600',
                'open_date': date.today() - timedelta(days=30),
                'close_date': date.today() - timedelta(days=27),
                'listing_date': date.today() - timedelta(days=20),
                'issue_size': 1000.00,
                'issue_type': 'book_building',
                'status': 'listed',
                'ipo_price': 1550.00,
                'listing_price': 1800.00,
                'current_market_price': 1750.00,
            },
            {
                'company_name': 'EduTech Learning Ltd',
                'price_band': '₹700-800',
                'open_date': date.today() - timedelta(days=45),
                'close_date': date.today() - timedelta(days=42),
                'listing_date': date.today() - timedelta(days=35),
                'issue_size': 250.00,
                'issue_type': 'fixed_price',
                'status': 'listed',
                'ipo_price': 750.00,
                'listing_price': 720.00,
                'current_market_price': 680.00,
            },
            {
                'company_name': 'LogiTech Transport Ltd',
                'price_band': '₹600-700',
                'open_date': date.today() - timedelta(days=60),
                'close_date': date.today() - timedelta(days=57),
                'listing_date': date.today() - timedelta(days=50),
                'issue_size': 350.00,
                'issue_type': 'offer_for_sale',
                'status': 'listed',
                'ipo_price': 650.00,
                'listing_price': 800.00,
                'current_market_price': 950.00,
            },
            {
                'company_name': 'RetailMart Stores Ltd',
                'price_band': '₹2000-2200',
                'open_date': date.today() - timedelta(days=90),
                'close_date': date.today() - timedelta(days=87),
                'listing_date': date.today() - timedelta(days=80),
                'issue_size': 1500.00,
                'issue_type': 'book_building',
                'status': 'listed',
                'ipo_price': 2100.00,
                'listing_price': 2400.00,
                'current_market_price': 2200.00,
            },
        ]

        created_count = 0
        for ipo_data in sample_ipos:
            ipo, created = IPO.objects.get_or_create(
                company_name=ipo_data['company_name'],
                defaults=ipo_data
            )
            if created:
                created_count += 1
                self.stdout.write(f'Created IPO: {ipo.company_name}')

        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully created {created_count} sample IPOs'
            )
        )

        # Display summary
        total_upcoming = IPO.objects.filter(status='upcoming').count()
        total_ongoing = IPO.objects.filter(status='ongoing').count()
        total_listed = IPO.objects.filter(status='listed').count()

        self.stdout.write(f'\nSummary:')
        self.stdout.write(f'- Upcoming IPOs: {total_upcoming}')
        self.stdout.write(f'- Ongoing IPOs: {total_ongoing}')
        self.stdout.write(f'- Listed IPOs: {total_listed}')
        self.stdout.write(f'- Total IPOs: {IPO.objects.count()}') 