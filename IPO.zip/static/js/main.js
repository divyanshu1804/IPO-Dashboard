// Enhanced IPO Tracker - Modern JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeTooltips();
    initializePopovers();
    initializeSearch();
    initializeFilters();
    initializePerformanceMetrics();
    initializeSmoothScrolling();
    initializeLoadingStates();
    initializeScrollAnimations();
    initializeNavbarEffects();
    initializeCounters();
    initializeParallaxEffects();
});

// Enhanced Tooltips
function initializeTooltips() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl, {
            animation: true,
            delay: { show: 100, hide: 100 }
        });
    });
}

// Enhanced Popovers
function initializePopovers() {
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl, {
            animation: true,
            trigger: 'hover'
        });
    });
}

// Enhanced Search functionality
function initializeSearch() {
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.classList.add('loading');
                
                // Add typing animation
                this.style.transform = 'scale(1.02)';
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                }, 200);
                
                setTimeout(() => {
                    this.classList.remove('loading');
                }, 500);
            }, 300);
        });
        
        // Auto-focus search on page load
        if (window.location.search.includes('search=')) {
            searchInput.focus();
        }
    }
}

// Enhanced Filter functionality
function initializeFilters() {
    const filterForm = document.querySelector('form[action*="ipo_list"]');
    if (filterForm) {
        const filterInputs = filterForm.querySelectorAll('select, input');
        
        filterInputs.forEach(input => {
            input.addEventListener('change', function() {
                filterForm.classList.add('loading');
                
                // Add change animation
                this.style.transform = 'scale(1.05)';
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                }, 200);
                
                setTimeout(() => {
                    filterForm.submit();
                }, 300);
            });
        });
    }
}

// Enhanced Performance metrics animation
function initializePerformanceMetrics() {
    const performanceElements = document.querySelectorAll('.performance-metric');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in-up');
                
                // Add pulse animation for positive performance
                if (entry.target.classList.contains('performance-positive')) {
                    entry.target.classList.add('animate-pulse');
                    setTimeout(() => {
                        entry.target.classList.remove('animate-pulse');
                    }, 2000);
                }
                
                observer.unobserve(entry.target);
            }
        });
    });
    
    performanceElements.forEach(element => {
        observer.observe(element);
    });
}

// Enhanced Smooth scrolling
function initializeSmoothScrolling() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Enhanced Loading states
function initializeLoadingStates() {
    const buttons = document.querySelectorAll('button[type="submit"], .btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            if (!this.classList.contains('disabled')) {
                this.classList.add('loading');
                
                // Add ripple effect
                const ripple = document.createElement('span');
                ripple.classList.add('ripple');
                this.appendChild(ripple);
                
                setTimeout(() => {
                    this.classList.remove('loading');
                    ripple.remove();
                }, 2000);
            }
        });
    });
}

// Scroll animations
function initializeScrollAnimations() {
    const animatedElements = document.querySelectorAll('.animate-fade-in-up, .animate-slide-in-left');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}

// Navbar effects
function initializeNavbarEffects() {
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
            navbar.style.padding = '0.75rem 0';
        } else {
            navbar.classList.remove('scrolled');
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
            navbar.style.padding = '1rem 0';
        }
    });
    
    // Add active state to current page
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href').split('?')[0]; // Remove query parameters
        if (linkPath === currentPath) {
            link.classList.add('active');
        }
    });
    
    // Smooth scroll for navbar links
    const navbarLinks = document.querySelectorAll('.navbar-nav .nav-link[href^="#"]');
    navbarLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const navbarHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetElement.offsetTop - navbarHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Counter animations
function initializeCounters() {
    const counters = document.querySelectorAll('.stats-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalValue = parseInt(target.textContent);
                let currentValue = 0;
                const increment = finalValue / 50;
                
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= finalValue) {
                        target.textContent = finalValue;
                        clearInterval(timer);
                    } else {
                        target.textContent = Math.floor(currentValue);
                    }
                }, 30);
                
                observer.unobserve(target);
            }
        });
    });
    
    counters.forEach(counter => {
        observer.observe(counter);
    });
}

// Parallax effects
function initializeParallaxEffects() {
    const parallaxElements = document.querySelectorAll('.hero-section');
    
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        
        parallaxElements.forEach(element => {
            const rate = scrolled * -0.5;
            element.style.transform = `translateY(${rate}px)`;
        });
    });
}

// Enhanced API Functions
const API = {
    // Fetch IPOs with filters
    async fetchIPOs(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const url = `/api/ipo/${queryString ? '?' + queryString : ''}`;
        
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching IPOs:', error);
            Utils.showNotification('Error fetching IPOs', 'danger');
            throw error;
        }
    },
    
    // Fetch IPO details
    async fetchIPODetails(id) {
        try {
            const response = await fetch(`/api/ipo/${id}/`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching IPO details:', error);
            Utils.showNotification('Error fetching IPO details', 'danger');
            throw error;
        }
    },
    
    // Fetch IPO performance
    async fetchIPOPerformance(id) {
        try {
            const response = await fetch(`/api/ipo/${id}/performance/`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return await response.json();
        } catch (error) {
            console.error('Error fetching IPO performance:', error);
            Utils.showNotification('Error fetching IPO performance', 'danger');
            throw error;
        }
    }
};

// Enhanced Utility Functions
const Utils = {
    // Format currency
    formatCurrency(amount, currency = '₹') {
        if (!amount) return '-';
        return `${currency}${parseFloat(amount).toLocaleString('en-IN')}`;
    },
    
    // Format percentage
    formatPercentage(value) {
        if (value === null || value === undefined) return '-';
        return `${parseFloat(value).toFixed(1)}%`;
    },
    
    // Format date
    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    },
    
    // Get status color class
    getStatusColor(status) {
        const colors = {
            'upcoming': 'warning',
            'ongoing': 'primary',
            'listed': 'success'
        };
        return colors[status] || 'secondary';
    },
    
    // Enhanced notification system
    showNotification(message, type = 'info') {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.notification-toast');
        existingNotifications.forEach(notification => notification.remove());
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification-toast alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = `
            top: 100px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            max-width: 400px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            border: none;
            border-radius: 12px;
            animation: slideInRight 0.3s ease;
        `;
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="bi bi-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                <span>${message}</span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }
        }, 5000);
    },
    
    // Debounce function
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    // Throttle function
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }
};

// Enhanced Chart functionality
const Charts = {
    // Initialize performance chart
    initPerformanceChart(containerId, data) {
        const container = document.getElementById(containerId);
        if (container && data) {
            // Create a simple performance visualization
            const chartHtml = `
                <div class="performance-chart">
                    <div class="chart-header">
                        <h6 class="mb-2">Performance Overview</h6>
                    </div>
                    <div class="chart-bars">
                        ${data.listing_gain ? `
                            <div class="chart-bar">
                                <div class="bar-label">Listing Gain</div>
                                <div class="bar-container">
                                    <div class="bar-fill ${data.listing_gain >= 0 ? 'positive' : 'negative'}" 
                                         style="width: ${Math.min(Math.abs(data.listing_gain), 100)}%"></div>
                                </div>
                                <div class="bar-value">${data.listing_gain}%</div>
                            </div>
                        ` : ''}
                        ${data.current_return ? `
                            <div class="chart-bar">
                                <div class="bar-label">Current Return</div>
                                <div class="bar-container">
                                    <div class="bar-fill ${data.current_return >= 0 ? 'positive' : 'negative'}" 
                                         style="width: ${Math.min(Math.abs(data.current_return), 100)}%"></div>
                                </div>
                                <div class="bar-value">${data.current_return}%</div>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
            container.innerHTML = chartHtml;
        }
    }
};

// Add CSS for new animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.6);
        transform: scale(0);
        animation: ripple-animation 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .performance-chart {
        padding: 1rem;
        background: rgba(255, 255, 255, 0.9);
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .chart-bar {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .bar-label {
        width: 100px;
        font-size: 0.875rem;
        font-weight: 500;
    }
    
    .bar-container {
        flex: 1;
        height: 8px;
        background: #e2e8f0;
        border-radius: 4px;
        margin: 0 1rem;
        overflow: hidden;
    }
    
    .bar-fill {
        height: 100%;
        border-radius: 4px;
        transition: width 0.6s ease;
    }
    
    .bar-fill.positive {
        background: linear-gradient(90deg, #10b981, #059669);
    }
    
    .bar-fill.negative {
        background: linear-gradient(90deg, #ef4444, #dc2626);
    }
    
    .bar-value {
        width: 60px;
        text-align: right;
        font-size: 0.875rem;
        font-weight: 600;
    }
`;
document.head.appendChild(style);

// Export for global access
window.IPOApp = {
    API,
    Utils,
    Charts
}; 